# AIMO (see aimo folder for source code :)
This is a repo containing the source code to solving the 2022 (and maybe beyond?) for the set of math problems known under the common name AIMO

This was an invite-only program :( but I have made the solutions (and eventually the questions) public **HERE!**
