from setuptools import setup

if __name__ == "__main__":
    print("Setting up AIMO ...")
    setup()