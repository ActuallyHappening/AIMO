print("YAY! __init__.py ran from AIMO!")
