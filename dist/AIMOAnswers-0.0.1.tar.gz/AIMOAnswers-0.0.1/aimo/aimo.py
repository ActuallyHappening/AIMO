class PS3:
    def Problem1():
      return "Problem 1 -- TODO actually solve"